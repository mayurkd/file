package com.gitlab.example.rest.api;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gitlab.example.dto.MyData;
import com.gitlab.example.service.GitHubFileUploadService;
import com.gitlab.example.service.JsonGenerationService;

import java.io.File;
import java.io.IOException;
import java.util.List;

@RestController
public class FileUploadController {

    @Autowired
    private JsonGenerationService jsonGenerationService;

    @Autowired
    private GitHubFileUploadService gitHubFileUploadService;
    
    @PostMapping("/generate-and-upload")
    public ResponseEntity<String> generateAndUpload() {
        try {
            jsonGenerationService.generateAndSaveJson();
            File file = new File("C:/abc/reJson.json"); // Local file path
            gitHubFileUploadService.uploadFileToGitHub(file);
            return ResponseEntity.ok("File generated and uploaded successfully to GitHub.");
        } catch (IOException | GitAPIException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to generate or upload file: " + e.getMessage());
        }
    }
}

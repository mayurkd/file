package com.gitlab.example.service;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.File;
import java.io.IOException;

@Service
public class GitHubFileUploadService {

    @Value("${github.username}")
    private String username;

    @Value("${github.password}")
    private String password;

    public void uploadFileToGitHub(File file) throws IOException, GitAPIException {
        Git git = Git.init().setDirectory(new File("C:/abc")).call();
        git.add().addFilepattern(".").call();
        git.commit().setMessage("Add file").call();

        // Push changes to GitHub
        git.push()
           .setCredentialsProvider(new UsernamePasswordCredentialsProvider(username, password))
           .call();
    }
}